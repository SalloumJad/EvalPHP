<?php include("inc/header.inc.php"); ?>


<?php 
if(!empty($_POST) && isset($_POST['save']))
{
    $result = $pdo->query("INSERT INTO experience (titre, sous_titre, competances_acquises, periode) VALUES ('$_POST[titre]', '$_POST[sous_titre]', '$_POST[competances_acquises]', '$_POST[periode]')");
} ?>

<?php // Ici j'initialise les variables o� j'�tais cens� mettre les contenus de l'objet � modifier apr�s avoir cliqu� sur le bouton. C'est pour ne pas causer d'erreur ou d'affichage en trop quand on recharge ou quand on fait une autre action que modifier.
$modif_titre = "";
$modif_sous_titre = "";
$modif_competances_acquises = "";
$modif_periode = "";
?>

<div class="starter-template">  
    <form method="POST" action="" enctype='multipart/form-data'>

        <div class="form-group">
            <label for="titre">Titre du paragraphe</label>
            <input type="texte" class="form-control" id="titre" name="titre" placeholder=<?php echo $modif_titre // j'ai test� avec placeholder et value pour voir si le contenu des inputs changait. J'avais vu que "normalement" cette m�thode fonctionnait sans module suppl�mentaire mais elle n'a pas fonctionn� ici. J'ai aussi tent� avec la m�thode GET mais mes capacit�s sont trpo basses pour m�langer tant de choses � la fois, m�me avec des examples.?>>
        </div>

        <div class="form-group">
            <label for="sous_titre">Sous-titre du paragraphe</label>
            <input type="texte" class="form-control" id="sous_titre" name="sous_titre" value=<?php echo $modif_sous_titre?>>
        </div>

        <div class="form-group">
            <label for="competances_acquises">Contenu du paragraphe</label>
            <textarea rows="10" class="form-control" id="competances_acquises" name="competances_acquises" value=<?php echo $modif_competances_acquises?>></textarea>
        </div>

        <div class="form-group">
            <label for="periode">Periode de l'evenement</label>
            <input type="texte" class="form-control" id="periode" name="periode" value=<?php echo $modif_periode?>>
        </div>

        <button type="submit" class="btn btn-primary" name="save">Enregistrer</button>

    </form>
</div>
    

<br>
<br>
<br>

<?php
$result = $pdo->query("SELECT * FROM experience WHERE titre != ''");

while ($experience = $result->fetch(PDO::FETCH_OBJ)) { ?>
    <form method="POST" action="" enctype='multipart/form-data'>
        <div class="resume-item d-flex flex-column flex-md-row justify-content-between mb-5">
            <div class="resume-content">
            <h3 class="mb-0"><?php echo $experience->titre ?></h3>
            </div>
            <button type="submit" class="btn btn-primary" name="modify">Modifier</button>
            <button type="submit" class="btn btn-primary" name="delete">Supprimer</button>
        </div>
    </form>
    <?php
    if(!empty($_POST) && isset($_POST['delete'])){
        $result2 = $pdo->exec("DELETE FROM experience WHERE id_experience = $experience->id_experience");
    }
    else if(!empty($_POST) && isset($_POST['modify'])){
        $modif_titre = $experience->titre;
        $modif_sous_titre = $experience->sous_titre;
        $modif_competances_acquises = $experience->competances_acquises;
        $modif_periode = $experience->periode;
        // tentative de faire une modification, mais qui n'a pas fonctionn�. Je comptais remplir les input au dessus avec les infos de l'objet puis utiliser UPDATE pour mettre � jour... mais �a n'a pas fonctionn� (j'ai test� d'autres choses aussi)
    }
} ?>

<?php include("inc/footer.inc.php"); ?>