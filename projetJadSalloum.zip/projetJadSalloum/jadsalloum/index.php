<?php include("inc/header.inc.php"); // J'ai séparé chaque partie dans des include pour que les changer d'ordre soit plus facile. J'ai testé et normalement, ils sont tous interchangables (sauf header et footer bien sur) ?>

<?php include("inc/about.inc.php"); ?>

<?php include("inc/experience.inc.php"); ?>

<?php include("inc/education.inc.php"); ?>

<?php include("inc/skills.inc.php"); ?>

<?php include("inc/interests.inc.php"); ?>

<?php include("inc/awards.inc.php"); ?>

<?php include("inc/footer.inc.php"); ?>